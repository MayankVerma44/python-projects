from replit import clear
#HINT: You can call clear() to clear the output in the console.
from art import logo
print(logo)
bids={}
bidding_finish= False
def highest_bidder(bidding_record):
  highest_bid =0
  winner=""  
  for bidder in bidding_record:
 
    bid_amount = int(bidding_record[bidder])
    if bid_amount > highest_bid:
      highest_bid = bid_amount
      winner = bidder
  print(f"THE WINNER IS {winner} WITH A BID OF ${highest_bid}")
while not bidding_finish:
  name= input("what is your name: ")
  price = input(" What is your BID $:")
  bids[name] = price
  should_continue = input("ARE THERE ANY OTHER BIDDERS ? type 'yes' or 'no'.")
  if should_continue == "no":
    bidding_finish = True
    highest_bidder(bids)
  elif should_continue == "yes" :
    clear()
    
